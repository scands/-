package version

const VERSION = "0.23.1"

// Compulsory minimum version, Minimum downward compatibility to this version
func GetVersion() string {
	return "0.21.0"
}
