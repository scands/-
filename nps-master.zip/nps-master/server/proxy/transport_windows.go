// +build windows

package proxy

import (
	"github.com/cnlh/nps/lib/conn"
)

func HandleTrans(c *conn.Conn, s *TunnelModeServer) error {
	return nil
}
